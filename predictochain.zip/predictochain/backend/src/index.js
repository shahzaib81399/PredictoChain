require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Middlewares
app.use(cors());
app.use(bodyParser.json());

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// TODO: Implement authentication, subscription, token verification, and reporting routes here.

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`PredictoChain backend listening on port ${PORT}`);
});