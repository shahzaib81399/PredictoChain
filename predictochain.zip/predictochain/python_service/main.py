from fastapi import FastAPI

app = FastAPI(title="PredictoChain Signal Service")

@app.get("/health")
async def health_check():
    """Simple health check endpoint"""
    return {"status": "ok"}

# TODO: Add endpoints to execute custom trading signal scripts securely.

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)